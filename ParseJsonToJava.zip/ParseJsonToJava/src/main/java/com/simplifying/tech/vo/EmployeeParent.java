package com.simplifying.tech.vo;

public class EmployeeParent {
	
	private EmpInfo empInfo;
    private Skills[] skills;
	public EmpInfo getEmpInfo() {
		return empInfo;
	}
	public void setEmpInfo(EmpInfo empInfo) {
		this.empInfo = empInfo;
	}
	public Skills[] getSkills() {
		return skills;
	}
	public void setSkills(Skills[] skills) {
		this.skills = skills;
	}
 
//Generate Getters and Setters for above 2 objects
    
    

}
