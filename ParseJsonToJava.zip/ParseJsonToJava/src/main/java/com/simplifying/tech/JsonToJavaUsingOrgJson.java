package com.simplifying.tech;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;

public class JsonToJavaUsingOrgJson {
    
	private static void parseJSONToCSV(String path) throws IOException {
		File directory = new File(path);
		File[] fileArray = directory.listFiles();
		
		File csvFile = new File("test.csv");
		
		
		BufferedReader br;
		JSONObject jsonObject;

		JSONArray jsonArray;
		
		for(File file : fileArray) {
			String jsonString ="";
			if(file.isFile()) {				
				try {					
					br = new BufferedReader(new FileReader(file));
					String line;  
			        StringBuilder sbuilderObj = new StringBuilder();
			        while((line=br.readLine()) !=null){
			            sbuilderObj.append(line);
			        }
			        jsonObject = new JSONObject(sbuilderObj);
			          
			        jsonArray = new JSONArray(sbuilderObj.toString());
			        
			        jsonString =  CDL.toString(jsonArray);
			        //System.out.println(jsonString);
			        FileUtils.writeStringToFile(csvFile, jsonString, true);
			        System.out.println(file.getName());
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}            
		        
			}
				
		}
		
		System.out.println("success");
	}
	
    public static void main(String[] args) throws IOException {
        
    	parseJSONToCSV("C:\\Users\\subod\\Downloads\\data\\data");
    	//Reading JSON from file system   
        
        //System.out.println("Original Json :: "+sbuilderObj.toString());
        //Using JSONObject 
        
        
 
    }
}
