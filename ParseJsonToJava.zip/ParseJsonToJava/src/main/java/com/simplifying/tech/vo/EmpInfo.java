package com.simplifying.tech.vo;

public class EmpInfo {
    
    private String name;
    private String position;
    private String salary;
    private String age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
     
    //Generate Getters and Setters for above 4 objects 
    
}