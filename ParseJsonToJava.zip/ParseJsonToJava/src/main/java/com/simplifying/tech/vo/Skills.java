package com.simplifying.tech.vo;

public class Skills {
    
    private String programming;
    private String scripting;
    private String ml;
	public String getProgramming() {
		return programming;
	}
	public void setProgramming(String programming) {
		this.programming = programming;
	}
	public String getScripting() {
		return scripting;
	}
	public void setScripting(String scripting) {
		this.scripting = scripting;
	}
	public String getMl() {
		return ml;
	}
	public void setMl(String ml) {
		this.ml = ml;
	}
     
    //Generate Getters and Setters for above 3 objects 
    
}
